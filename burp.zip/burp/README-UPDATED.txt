Edit start.sh in Parrot OS
mate-terminal --command="java --illegal-access=permit -Dfile.encoding=utf-8 -javaagent:/home/kali/Desktop/burp/loader.jar -noverify -jar /home/Kali/Desktop/burp/burpsuite_pro_v2022.3.5.jar & -c 'cd /home/kali/Desktop/burp; ls. $SHELL'"
Open the folder where your Burpsuite is located or you downloaded using github
Now open terminal from same window, by right click and open terminal in window
now run the command "chmod +x /home/nikhil/Desktop/burp/start.sh"
Right click and then left click on Create Launcher
Select below options in window:
Type: Application in Terminal
Name: Start Burpsuite
Command: /home/nikhil/Desktop/burp/start.sh (Path to start.sh - Bash File)
Comment: Start Burp or Start Burpsuite
